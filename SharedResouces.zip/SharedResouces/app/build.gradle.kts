plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.example.sharedresouces"
    compileSdk {
        version = release(36) {
            minorApiLevel = 1
        }
    }

    defaultConfig {
        minSdk = 24
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    androidComponents {
        beforeVariants { variant ->
            if (variant.buildType == "debug") {
                variant.enable = false
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    buildFeatures {
        compose = true
    }
}

// Keeping the task in case they still want to generate public.xml for the AAR, 
// although it's less common for libraries.
tasks.register("generatePublicXml") {
    group = "build"
    description = "Generates public.xml from R.txt to ensure all resources (including new ones) are captured."

    doLast {
        val buildDir = layout.buildDirectory.get().asFile
        
        // Search for R.txt in common AGP output locations for libraries
        val rTxtFile = fileTree(buildDir) {
            include("**/runtime_symbol_list/release/R.txt")
            include("**/symbol_list_with_package_name/release/R.txt")
            include("**/processReleaseResources/R.txt")
            include("**/compileReleaseR_shareable/R.txt")
        }.firstOrNull()

        val outputFile = file("src/main/res/values/public.xml")

        if (rTxtFile == null || !rTxtFile.exists()) {
            throw GradleException("ERROR: R.txt not found. Please run './gradlew assembleRelease' first.")
        }

        println("INFO: Generating public.xml from ${rTxtFile.absolutePath}")
        
        val publicEntries = mutableListOf<String>()
        rTxtFile.forEachLine { line ->
            val parts = line.split(" ")
            if (parts.size >= 4) {
                val type = parts[1].trim()
                val name = parts[2].trim()
                val id = parts[3].trim()
                publicEntries.add("    <public type=\"$type\" name=\"$name\" id=\"$id\" />")
            }
        }

        outputFile.parentFile.mkdirs()
        val content = StringBuilder()
        content.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n")
        content.append("<!-- Auto-generated from R.txt - Do not edit manually -->\n")
        content.append("<resources>\n")
        publicEntries.distinct().sorted().forEach { content.append(it).append("\n") }
        content.append("</resources>")
        
        outputFile.writeText(content.toString())
        println("INFO: Successfully generated public.xml with ${publicEntries.size} entries.")
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    debugImplementation(libs.androidx.compose.ui.tooling)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
}
